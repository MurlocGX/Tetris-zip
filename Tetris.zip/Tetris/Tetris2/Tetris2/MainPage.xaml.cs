﻿using System;
using Tetris2.GameLogic;
using Xamarin.Forms;

namespace Tetris2
{
    public partial class MainPage : ContentPage
    {
        private GameManager gameManager;

        private Grid field = null;

        private View[,] viewElements;

        public Grid Field {
            get { return field; }
        }

        //Constructor wird von Xamarin beim start aufgerufen da diese Klasse von ContentPage erbt
        public MainPage()
        {
            //Diese funktion kommt von der ContentPage Klasse und sorgt dafür das die Elemente im xaml file initialisiert wird
            InitializeComponent();
            field = this.FindByName<Grid>("GameField");
            InitField();
            gameManager = GameManager.Instance;
            gameManager.Init(viewElements);
        }

        //Initialisiert das Visuelle Grid per Code
        public void InitField() {
            AddRowAndColumnDefinitions();
            AddColumnElements();
        }

        //Fügt dem Grid die Row und Column definitionen hinzu 
        private void AddRowAndColumnDefinitions() {
            for (int x = 0;x < 10; x++) {
                ColumnDefinition column = new ColumnDefinition();
                GridLength width = new GridLength(2,GridUnitType.Star);
                column.Width = width;
                field.ColumnDefinitions.Add(column);
            }

            for (int y = 0;y < 20;y++) {
                RowDefinition row = new RowDefinition();
                GridLength height = new GridLength(2, GridUnitType.Star);
                row.Height = height;
                field.RowDefinitions.Add(row);
            }
        }

        //Fügt den Grid die Elemente hinzu die wir als Spielfeld nutzen
        private void AddColumnElements() {
            viewElements = new View[10, 20];
            for (int x = 0;x < 10;x++) {
                for (int y = 0;y < 20;y++) {
                    Label label = new Label();
                    label.BackgroundColor = Color.Red;
                    field.Children.Add(label,x,y);
                    viewElements[x, y] = label;
                }
            }
        }
        //Ruft über den GameManager die MoveRight funktion für das Spielfeld auf
        private void MoveRight(object sender, EventArgs e) {
            gameManager.MoveCurrentBlock(1);
        }
        //Ruft über den GameManager die MoveLeft funktion für das Spielfeld auf
        private void MoveLeft(object sender, EventArgs e)
        {
            gameManager.MoveCurrentBlock(-1);
        }

    }
}
