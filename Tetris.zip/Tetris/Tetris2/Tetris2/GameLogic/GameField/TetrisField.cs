﻿using System;
using System.Collections.Generic;
using System.Numerics;
using Tetris2.GameLogic.Blocks;
using Xamarin.Forms;

namespace Tetris2.GameLogic.GameField
{
    public class TetrisField
    {
        private Color defaultColor = Color.Red;

        private Color freezeColor = Color.Blue;


        private Vector2 defaultGridSize = new Vector2(10,20);

        private int updateMovDirY = 1;
        public Vector2 DefaultGridSize
        {
            get { return defaultGridSize; }
        }

        private TetrisBlock currentBlock;

        private Vector2 currentBlockPosition;

        public void SetNextMovingTetrisBlock(TetrisBlock tetrisBlock) {
            currentBlock = tetrisBlock;
            currentBlockPosition = new Vector2();
        }

        private View[,] viewColumns;

        //Konstruiert die Tetris field klasse und setzt die viewElements
        public TetrisField(View[,] viewElements) {
            viewColumns = viewElements;
        }

        public void Init() {
            //Holt sich einen Random Block und setzt die aktuelle position zu 0,0 was oben Links im Bildschirm ist 
            currentBlock = BlockSpawner.GetNextBlock();
            currentBlockPosition = Vector2.Zero;

            //Hier wird die Initiale Position des Blocks ganz am Anfang des Spiel im Feld angegeben
            for (int i = 0;i < currentBlock.BlockCoordinates.Count;i++) {
                viewColumns[(int)currentBlock.BlockCoordinates[i].X + (int)currentBlockPosition.X,(int)currentBlock.BlockCoordinates[i].Y + (int)currentBlockPosition.Y].BackgroundColor = currentBlock.BlockColor;
            }
        }
       
        public void Update() {
            UpdateBlockPositionPerFrame();
        }

        //Überprüft ob es unter dem aktuellen block zur kollision kommt, anhand der Column farbe
        //setzt auch nächste update position
        private bool isCollidingVertical() {
            currentBlockPosition = new Vector2(currentBlockPosition.X, currentBlockPosition.Y + updateMovDirY);
            for (int i = 0; i < currentBlock.BlockCoordinates.Count; i++)
            {
                Console.WriteLine(currentBlock.BlockCoordinates[i].Y + currentBlockPosition.Y);

                if (currentBlock.BlockCoordinates[i].Y + currentBlockPosition.Y >= 20)
                {
                    Console.WriteLine("Hittet lower Bottom");
                    return true;
                } else if (viewColumns[(int)currentBlock.BlockCoordinates[i].X + (int)currentBlockPosition.X, (int)(currentBlock.BlockCoordinates[i].Y + currentBlockPosition.Y)].BackgroundColor == freezeColor) {
                    Console.WriteLine("Hittet a block underneath");
                    return true;
                }
            }
            return false;
        }

        //Update loop für das Tetris Feld
        private void UpdateBlockPositionPerFrame() {
            if (currentBlock != null) {
                //färbt aktuelle position in standard farbe 
                for (int i = 0; i < currentBlock.BlockCoordinates.Count; i++)
                {
                    viewColumns[(int)(currentBlock.BlockCoordinates[i].X + currentBlockPosition.X), (int)(currentBlock.BlockCoordinates[i].Y + currentBlockPosition.Y)].BackgroundColor = defaultColor;
                }

                if (isCollidingVertical())
                {
                    FreezeBlock();
                    SpawnNextBlock();
                }
                else
                {
                    MoveBlockPerUpdate();
                }
            }
          
        }

        //Färbt blöcke mit der Freeze farbe ein 
        private void FreezeBlock() {
            Console.WriteLine("Freezing Blocks");
            for (int i = 0; i < currentBlock.BlockCoordinates.Count; i++)
            {
                viewColumns[(int)(currentBlock.BlockCoordinates[i].X + currentBlockPosition.X), (int)(currentBlock.BlockCoordinates[i].Y + currentBlockPosition.Y - 1)].BackgroundColor = freezeColor;
            }
        }
        //Färbt die nächste Position mit block farbe
        private void MoveBlockPerUpdate() {
            Console.WriteLine("Moving Blocks");
            for (int i = 0; i < currentBlock.BlockCoordinates.Count; i++)
            {
                viewColumns[(int)(currentBlock.BlockCoordinates[i].X + currentBlockPosition.X), (int)(currentBlock.BlockCoordinates[i].Y + currentBlockPosition.Y)].BackgroundColor = currentBlock.BlockColor;
            }
        }
        //Holt sich einen neuen block und resettet die Position des Blocks
        private void SpawnNextBlock() {
            currentBlock = BlockSpawner.GetNextBlock();
            currentBlockPosition = Vector2.Zero;
        }
        //Überprüft ob es neben dem aktuellen block zur kollision kommt, anhand der Column farbe
        private bool isCollidingHorizontal(int dir) {
            for (int i = 0;i < currentBlock.BlockCoordinates.Count;i++) {
                Console.WriteLine("Moving block in X direction "+ + dir);
                if (currentBlock.BlockCoordinates[i].X + currentBlockPosition.X + dir < 0) {
                    return true;
                } else if (currentBlock.BlockCoordinates[i].X + currentBlockPosition.X + dir > 9) {
                    return true;
                } else if (viewColumns[(int)currentBlock.BlockCoordinates[i].X + (int)currentBlockPosition.X + dir, (int)(currentBlock.BlockCoordinates[i].Y + currentBlockPosition.Y)].BackgroundColor == freezeColor) {
                    return true;
                }
            }
            return false;
        }
        //verschiebt blöcke horizontal falls erlauft
        public void MoveBlockHorizontal(int dir) {
            if (!isCollidingHorizontal(dir)) {
                for (int i = 0; i < currentBlock.BlockCoordinates.Count; i++)
                {
                    viewColumns[(int)(currentBlock.BlockCoordinates[i].X + currentBlockPosition.X), (int)(currentBlock.BlockCoordinates[i].Y + currentBlockPosition.Y)].BackgroundColor = defaultColor;
                }
                currentBlockPosition.X += dir;
                MoveBlockPerUpdate();
            }      
        }
    }
}
