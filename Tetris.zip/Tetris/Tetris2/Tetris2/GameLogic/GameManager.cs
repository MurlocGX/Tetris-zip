﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Tetris2.GameLogic.GameField;
using Tetris2.GameLogic.Update;
using Xamarin.Forms;

namespace Tetris2.GameLogic
{
    //Singleton class because there should be only one instance be active 
    public class GameManager
    {
        private TetrisField grid;

        private static GameManager activeInstance;

        private GameUpdateLoop updateLoop;
    
        public static GameManager Instance {
            get {
                if (activeInstance != null) {
                    return activeInstance;
                }
                activeInstance = new GameManager();
                return activeInstance;                                
            }
        }

        public void Init(View[,] elements) {
            grid = new TetrisField(elements);
            grid.Init();
            updateLoop = new GameUpdateLoop(grid);
            updateLoop.StartGame();
        }

        public void SetUpANewRound() {
        }

        public void Resume() {
         
        }
        public void Pause() { 
        
        }

        public void MoveCurrentBlock(int movDirX) {
            grid.MoveBlockHorizontal(movDirX);
        }

    }
}
