﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using System.Text;
using Xamarin.Forms;

namespace Tetris2.GameLogic.Blocks
{
    public abstract class TetrisBlock
    {
        //Diese Liste wird verwendet, um die einzelnen Koordinaten der blöcke im TetrisBlock zu speichern
        private List<Vector2> blockCoordinates = new List<Vector2>();
        public List<Vector2> BlockCoordinates
        {
            get { return blockCoordinates; }
        }

        //Hält die Farbe des Blocks
        protected Color blockColor;

        //Getter ermöglicht readonly zugriff von außen
        public Color BlockColor
        {
            get { return blockColor; }
        }
       
    }
}
