﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Tetris2.GameLogic.Blocks
{
    public static class BlockSpawner
    {
        private static List<TetrisBlock> avalibleBlocks = new List<TetrisBlock>() {
            new OneBlock(Color.Orange)
        };

        public static TetrisBlock GetNextBlock(){
            Random random = new Random();
            int randomBlock = random.Next(0,avalibleBlocks.Count);
            return avalibleBlocks[randomBlock];
        }
    }
}
