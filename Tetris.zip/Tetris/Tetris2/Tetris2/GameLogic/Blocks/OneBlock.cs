﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;
using Xamarin.Forms;

namespace Tetris2.GameLogic.Blocks
{
    public class OneBlock : TetrisBlock
    {
        public OneBlock(Color color)
        {
            blockColor = color;
            BlockCoordinates.Add(new Vector2(0, 0));
            BlockCoordinates.Add(new Vector2(0, 1));
            BlockCoordinates.Add(new Vector2(0, 2));
            BlockCoordinates.Add(new Vector2(0, 3));
        }
    }
}
