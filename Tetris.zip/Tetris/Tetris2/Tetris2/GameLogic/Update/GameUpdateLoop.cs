﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Tetris2.GameLogic.GameField;

namespace Tetris2.GameLogic.Update
{
    public class GameUpdateLoop
    {
        public bool IsGameRunning = true;
        private bool isPausing = false;

        private GameField.TetrisField grid;
        public GameUpdateLoop(GameField.TetrisField _grid) {
            grid = _grid;
        }

        public void StartGame() {
            Action runLoop = new Action(RunGameLoop);
            DelayedAction(runLoop, 0);
        }

        public static void DelayedAction(Action action,int millis) {
            Task.Run(async () => {
                Thread.Sleep(millis);
                action();
            });
        }

        private void RunGameLoop() {
            while (IsGameRunning) {
                grid.Update();
                //Highscore
                Thread.Sleep(500);
            }
            //Save everything
            //End Game
        }

        public void PauseGame() {
            isPausing = true;
        }

        public void ResumeGame() {
            isPausing = false;
        }

        public void EndGame() {
            IsGameRunning = false;
        }

    }
}
